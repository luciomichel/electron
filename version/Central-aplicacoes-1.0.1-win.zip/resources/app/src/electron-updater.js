const updater = require('electron-simple-updater');
const os = require('os');
const path = require('path');
const { dialog, Notification, app } = require('electron');
const axios = require('axios');

const tempoVerificacaoVersao = 30 * 60 * 1000;

const init = () => {
  updater.init({
    url:
      'https://nexus.farmaciassaojoao.com.br/repository/static-hosted/central-aplicacoes/updater.json',
    checkUpdateOnStart: false,
  });

  attachUpdaterHandlers();

  setTimeout(() => {
    console.log('Iniciando app versao:', app.getVersion());

    recursiveCheckVersion();
  }, 10 * 1000);
};

const recursiveCheckVersion = () => {
  checkVersion();

  setTimeout(() => {
    recursiveCheckVersion();
  }, tempoVerificacaoVersao);
};

const checkVersion = () => {
  console.log('verificando atualizacoes...');
  updater.checkForUpdates();
};

function showNotification({ title, body }) {
  const notification = {
    title: title,
    body: body,
  };
  new Notification(notification).show();
}

function attachUpdaterHandlers() {
  updater.on('update-available', onUpdateAvailable);
  updater.on('update-downloading', onUpdateDownloading);
  updater.on('update-downloaded', onUpdateDownloaded);
  updater.on('update-not-available', onUpdateNotAvailable);

  function onUpdateAvailable(meta) {
    showNotification({
      title: 'Atualização!',
      body: 'Há uma nova versão disponível! ' + meta.version,
    });

    verificarVersaoNoServidor(meta.version);
  }

  function onUpdateDownloading(meta) {
    console.log('Baixando nova versão');
  }

  function onUpdateNotAvailable() {
    console.log('Não é necessário atualizar o app');
  }

  async function onUpdateDownloaded() {
    const options = {
      buttons: ['Sim', 'Não'],
      message: 'Atualização finalizada, deseja reabrir o programa agora?',
    };

    const response = await dialog.showMessageBox(options);

    if (response.response === 0) {
      console.log('Reiniciando app...');
      updater.quitAndInstall();
    }

    console.log('Opcao selecionada no onUpdateDownloaded', response);
  }
}

async function verificarVersaoNoServidor(novaVersao) {
  const data = {
    app: 'FSJ_CENTRAL_APLICACOES',
    versaoAtual: app.getVersion(),
    versaoNova: novaVersao,
    so: os.platform(),
    osrelease: os.release(),
    hostname: os.hostname(),
  };

  // console.log('Manda a versão para o servidor', data);

  try {
    const resp = await axios.post(
      'http://192.168.0.37:11000' + '/gerenciadorversao/consultarVersao',
      data,
      {
        timeout: 5000,
      }
    );

    if (resp.data && resp.data.data && resp.data.data.dtLimiteFmt) {
      const dataLimite = new Date(Date.parse(resp.data.data.dtLimiteFmt));

      if (dataLimite.getTime() < new Date().getTime()) {
        console.log('Bloquear o App');
        bloquearUsoDoApp();
      } else {
        console.log('App liberado para uso, conforme API');
      }
    }
  } catch (e) {
    console.error('Erro ao consultar a versao.', e);
  }
}

function bloquearUsoDoApp() {
  const filePath = path.resolve(
    app.getAppPath(),
    'src',
    'contact-support.html'
  );
  app.emit('replace-window', filePath);
}

init();
